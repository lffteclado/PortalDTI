﻿namespace Fita_de_Preco.Models
{
    public class StatusPlanos
    {
        public string CodEmpresa { get; set; }

        public string NomeEmpresa { get; set; }

        public string Local { get; set; }

        public string PlanoBloqueio { get; set; }

        public string VendaAbaixoCusto { get; set; }

        public string DescontoMinimo { get; set; }

        public string ValorDescMinimo { get; set; }

    }
}
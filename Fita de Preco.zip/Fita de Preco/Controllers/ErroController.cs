﻿using System.Web.Mvc;

namespace Fita_de_Preco.Controllers
{
    public class ErroController : Controller
    {
        // GET: Erro
        public ActionResult Index()
        {
            return View();
        }
    }
}
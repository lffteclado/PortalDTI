﻿namespace Fita_de_Preco.Models
{
    public class Planos
    {
        public int CodigoEmpresa { get; set; }
        public int CodigoPlano { get; set; }
        public char PlanoBloqueado { get; set; }
    }
}